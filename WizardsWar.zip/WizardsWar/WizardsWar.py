import pygame as pg
import sys

pg.font.init()

font = pg.font.Font(None, 30)

# IMAGES

wizard1_raw = pg.image.load("wizard1.png")
wizard1 = pg.transform.scale(wizard1_raw, (180, 240))
wizard2_raw = pg.image.load("wizard2.png")
wizard2 = pg.transform.scale(wizard2_raw, (180, 240))
background = pg.image.load("background.jpg")
fireballRAW = pg.image.load("fireball.png")
fireball_img = pg.transform.scale(fireballRAW, (100, 100))
fireball_reversed = pg.transform.rotate(fireball_img, 180)
waterballRAW = pg.image.load("waterball.png")
waterball_img = pg.transform.scale(waterballRAW, (50, 50))
waterbsll_reversed = pg.transform.rotate(waterball_img, 180)


animating = 0
poisoned1 = 0
poisoned2 = 0
mana_1 = 20
mana_2 = 20
pl_1_hp = 20
pl_2_hp = 20
pl1_sleep = 0
pl2_sleep = 0
turn = 1 
valid_move = 0

# COLORS

L_BLUE = (156, 215, 229)
BLUE = (0, 0, 255)
RED = (255, 0, 0)
GREY = (128, 128, 128)
BLACK = (0,0,0)
WHITE = (255,255,255)

pg.init()
screen = pg.display.set_mode((1280, 720))

# VISUALIZATION

def Bar(surf, color, posx, posy, width, height):
    pg.draw.rect(surf, color, pg.Rect(posx, posy, width, height))


def updating_scene():
    screen.blit(background, (0, 0))
    screen.blit(wizard1, (20, 490))
    screen.blit(wizard2, (1100, 480))

# Redraw health bars and text

    text("Player 1", 100, 35, L_BLUE)
    text("Player 2", 1170, 35, L_BLUE)
    text("You can press 'I' to find out more about moves in the game.", 640, 60, WHITE)
    text(f"{pl_1_hp}/20", 110, 70, RED)
    text(f"{pl_2_hp}/20", 1170, 70, RED)
    text(f"{mana_1}/20", 110, 120, BLUE)
    text(f"{mana_2}/20", 1170, 120, BLUE)
    text("DUEL GAME", 640, 40, WHITE)

# Health Bar

    Bar(screen, GREY, 10, 80, 200, 20)
    Bar(screen, RED, 10, 80, width(pl_1_hp), 20)
    Bar(screen, GREY, 1070, 80, 200, 20)
    Bar(screen, RED, 1070, 80, width(pl_2_hp), 20)

# Mana Bar

    Bar(screen, GREY, 10, 130, 200, 20)
    Bar(screen, BLUE, 10, 130, width(mana_1), 20)
    Bar(screen, GREY, 1070, 130, 200, 20)
    Bar(screen, BLUE, 1070, 130, width(mana_2), 20)

# Turns

    if turn == 1:
        text("Player 1's turn", 640, 80, (209, 10, 93))
    elif turn == 2:
        text("Player 2's turn", 640, 80, (209, 10, 93))

# If poisoned

    if poisoned2:
        text("Player 2 you were successfully poisoned!", 630, 200, BLACK)
    elif poisoned1:
        text("Player 1 you were successfully poisoned!", 630, 200, BLACK)

# if asleep

    if pl1_sleep:
         text("Player 1 you are asleep!", 650, 200, BLACK)
    
    elif pl2_sleep:
        text("Player 2 you are asleep!", 650, 200, BLACK)

#Info menu

def menu():
    while True:
        screen.fill(WHITE)
        text("1. Fireball (F)", 650, 20, BLACK)
        text("- Effect: Deals 2 damage to the opponent.", 630, 50, BLACK)
        text("- Cost: Consumes 3 mana from the player.", 630, 80, BLACK)
        text("2. Water Orb (W)", 650, 110, BLACK)
        text("- Effect: Deals 5 damage to the opponent.", 630, 140, BLACK)
        text("- Cost: Consumes 6 mana from the player.", 630, 170, BLACK)
        text("3. Poison (P)", 650, 200, BLACK)
        text("- Effect: Deals 4 damage immediately, and an additional 3 damage on the next turn.", 630, 230, BLACK)
        text("- Cost: Consumes 5 mana from the player.", 630, 260, BLACK)
        text("4. Recovery (R)", 650, 290, BLACK)
        text("- Effect: Restores 30% of your mana. If your mana is at 0 or 1, it restores 100% of your mana instead.", 630, 320, BLACK)
        text("5. Sleep (S)", 650, 350, BLACK)
        text("- Effect: Restores 50% of your health. The player skips the next turn as they fall asleep.", 630, 380, BLACK)
        text("If you want to exit info window then just press any button on keyboard.", 910, 690, BLACK)
        pg.display.flip()
        pg.event.wait(1000)
        if pg.event.get():
            break


def animate_fireball():
    if turn == 1:
        for i in range(170, 1050, 3): 
            updating_scene()
            screen.blit(fireball_img, (i, 550))
            pg.display.flip()
            pg.time.wait(1)
    elif turn == 2:
        for i in range(1050, 170, -3): 
            updating_scene()
            screen.blit(fireball_reversed, (i, 550))
            pg.display.flip()
            pg.time.wait(1)


    updating_scene()

def animate_waterball():
    if turn == 1:
        for i in range(170, 1050, 3):  
            updating_scene()
            screen.blit(waterball_img, (i, 550))
            pg.display.flip()
            pg.time.wait(1)
    elif turn == 2:
        for i in range(1050, 170, -3): 
            updating_scene()
            screen.blit(waterbsll_reversed, (i, 550))
            pg.display.flip()
            pg.time.wait(1)


    updating_scene()

def text(text, posx, posy, color):
    text_surf = font.render(text, True, color)
    text_rect = text_surf.get_rect(center=(posx, posy))
    screen.blit(text_surf, text_rect)

def width(x):
    return x / 20 * 200

# INGAME MOVES

def fireball(x, y):
    animate_fireball()
    x -= 2
    y -= 3
    return x, y

def waterball(x, y):
    animate_waterball()
    x -= 5
    y -= 6
    return x, y

def poison(x, y):
    x -= 4
    y -= 5
    return x, y

def recovery(y):
    y += round(y * 0.30)
    if y > 20:
        y = 20
    elif y == 0 or y == 1:
        y = 20
    return y

def sleep(x):
    x += round(x * 0.5)
    if x > 20:
        x = 20  
    elif x == 0:
        x = 20
    return x


def die(x, y):
    if x <= 0:
        text(f"{y}, You've died!", 630, 200, BLACK)
        pg.display.flip()
        pg.time.wait(4000)
        sys.exit()

def player_move():
    global turn, pl_1_hp, pl_2_hp, mana_1, mana_2, poisoned1, poisoned2, pl1_sleep, pl2_sleep, valid_move, animating

    if turn == 1:
        if animating == 0:
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    pg.quit()
                    sys.exit()
                if event.type == pg.KEYDOWN and animating == 0:
                    if event.key == pg.K_w:  # Waterball
                        if mana_1 >= 6:
                            pl_2_hp, mana_1 = waterball(pl_2_hp, mana_1)
                            valid_move = 1
                            animating = 1
                        else:
                            text(f"You need at least 6 mana. You have {mana_1}", 650, 170, BLACK)
                            pg.display.flip()
                            pg.time.delay(1000)
                    elif event.key == pg.K_i:
                        menu()
                    elif event.key == pg.K_f:  # Fireball
                        if mana_1 >= 3:
                            pl_2_hp, mana_1 = fireball(pl_2_hp, mana_1)
                            valid_move = 1
                            animating = 1
                        else:
                            text(f"You need at least 3 mana. You have {mana_1}", 630, 170, BLACK)
                            pg.display.flip()
                            pg.time.delay(1000)
                    elif event.key == pg.K_p:  # Poison
                        if mana_1 >= 5:
                            
                            pl_2_hp, mana_1 = poison(pl_2_hp, mana_1)
                            poisoned2 = 1
                            valid_move = 1
                        else:
                            text(f"You need at least 5 mana. You have {mana_1}", 630, 170, BLACK)
                            pg.display.flip()
                            pg.time.delay(1000)                            
                    elif event.key == pg.K_r:  # Recovery
                        mana_1 = recovery(mana_1)
                        valid_move = 1
                    elif event.key == pg.K_s:  # Sleep
                        pl_1_hp = sleep(pl_1_hp)
                        pl1_sleep = 1
                        valid_move = 1
                    if poisoned1:
                        pl_1_hp -= 3
                        poisoned1 = 0
                    if valid_move:       # Change of moves
                        if pl2_sleep:
                            turn = 1
                            pl2_sleep = 0 
                        else:
                            turn = 2
                    valid_move = 0
                    pg.event.clear()  #prevents multi-pressing
                    animating = 0
    elif turn == 2:
        if animating == 0:
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    pg.quit()
                    sys.exit()
                if event.type == pg.KEYDOWN:
                    if event.key == pg.K_w:  # Waterball
                        if mana_2 >= 6:
                            pl_1_hp, mana_2 = waterball(pl_1_hp, mana_2)
                            valid_move = 1
                            animating = 1
                        else:
                            text(f"You need at least 6 mana. You have {mana_2}", 650, 170, BLACK)
                            pg.display.flip()
                            pg.time.delay(3000)

                    elif event.key == pg.K_i:
                        menu()

                    elif event.key == pg.K_f:  # Fireball
                        if mana_2 >= 3:
                            pl_1_hp, mana_2 = fireball(pl_1_hp, mana_2)
                            valid_move = 1
                            animating = 1
                        else:
                            text(f"You need at least 3 mana. You have {mana_2}", 630, 170, BLACK)
                            pg.display.flip()
                            pg.time.delay(1000)                            
                    elif event.key == pg.K_p:  # Poison
                        if mana_2 >= 5:
                            pl_1_hp , mana_2 = poison(pl_1_hp, mana_2)
                            poisoned1 = 1
                            valid_move = 1
                        else:
                            text(f"You need at least 5 mana. You have {mana_2}", 630, 170, BLACK)
                            pg.display.flip()
                            pg.time.delay(1000)                            
                    elif event.key == pg.K_r:  # Recovery
                        mana_2 = recovery(mana_2)
                        valid_move = 1
                    elif event.key == pg.K_s:  # Sleep
                        pl_2_hp = sleep(pl_2_hp)
                        pl2_sleep = 1
                        valid_move = 1
                    if poisoned2:
                        pl_2_hp -= 3  
                        poisoned2 = 0              
                    if valid_move:      # Change of moves
                        if pl1_sleep:
                            turn = 2
                            pl1_sleep = 0 
                        else:
                            turn = 1
                    valid_move = 0
                    pg.event.clear()
                    animating = 0

# MAIN Loop

while True:
    updating_scene()
    pg.display.flip()

    player_move()

# Check if Players have died

    die(pl_1_hp, "Player 1")  
    die(pl_2_hp, "Player 2")  
    pg.display.flip()
    pg.time.wait(100) 
